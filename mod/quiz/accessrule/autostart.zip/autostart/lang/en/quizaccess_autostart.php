<?php

$string['pluginname'] = 'Auto start quiz access rule';
$string['autostartheader'] = 'Start automatically';
$string['autostartheader_help'] = 'Configure automatic start options for the quiz.';
$string['autostartenabled'] = 'Start the quiz automatically';
$string['autostartenabled_help'] = 'If enabled, the quiz will open immediately without the intermediate start screen.';
